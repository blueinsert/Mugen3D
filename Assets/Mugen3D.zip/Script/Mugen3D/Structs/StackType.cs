﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct StackType
{
    public double value;
    public string strValue;

    public StackType(double v, string sv)
    {
        value = v;
        strValue = sv;
    }

}
